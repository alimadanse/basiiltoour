from django.urls import path
from .views import tour_detail, fill_form
from . import views


urlpatterns = [
    path('tour/<int:tour_id>/', tour_detail, name='tour_detail'),
    path('fill-form/<int:tour_id>/', fill_form, name='fill_form'),
    path('', views.home, name='home'),
]
