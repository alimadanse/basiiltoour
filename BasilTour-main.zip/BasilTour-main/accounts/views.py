from django.views import generic
from django.urls import reverse_lazy
from .forms import CusomUserCreationForm


class SignUpView(generic.CreateView):
    form_class = CusomUserCreationForm
    template_name = 'registration/signup.html'
    success_url = reverse_lazy('login')
    
